import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, roc_curve, auc, precision_recall_curve
from tensorflow.keras.models import Model
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input
from tensorflow.keras.preprocessing.image import ImageDataGenerator
from tensorflow.keras.layers import Dense, GlobalAveragePooling2D
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping

# Paths
train_path = "/content/drive/MyDrive/Datasets/MobileNet/Ham10000 Dataset/Classified Images/dataset_for_model/train"
validation_path = "/content/drive/MyDrive/Datasets/MobileNet/Ham10000 Dataset/Classified Images/dataset_for_model/validate"

# Data Generators
trainGenerator = ImageDataGenerator(preprocessing_function=preprocess_input).flow_from_directory(
    train_path, target_size=(224, 224), batch_size=30, class_mode='categorical')

validGenerator = ImageDataGenerator(preprocessing_function=preprocess_input).flow_from_directory(
    validation_path, target_size=(224, 224), batch_size=30, class_mode='categorical')

# Build the Model
baseModel = MobileNetV2(weights='imagenet', include_top=False)

x = baseModel.output
x = GlobalAveragePooling2D()(x)
x = Dense(512, activation='relu')(x)
x = Dense(256, activation='relu')(x)
x = Dense(128, activation='relu')(x)
predictLayer = Dense(7, activation='softmax')(x)  # 7 classes

model = Model(inputs=baseModel.input, outputs=predictLayer)

print(model.summary())

# Freeze Pretrained Layers
for layer in model.layers[:-5]:
    layer.trainable = False

# Compile the Model
model.compile(loss="categorical_crossentropy", optimizer=Adam(learning_rate=0.0001), metrics=['accuracy'])

# Early Stopping
early_stopping = EarlyStopping(monitor='val_loss', patience=20, verbose=1)

# Train the Model
history = model.fit(trainGenerator, validation_data=validGenerator, epochs=50, callbacks=[early_stopping])

# Save Model
path_for_saved_model = "/content/drive/MyDrive/Datasets/MobileNet/Ham10000 Dataset/Classified Images/dataset_for_model/TheHamV2.h5"
model.save(path_for_saved_model)

# Load Test Data
test_data, test_labels = next(validGenerator)  # Load one batch for evaluation

# Predict
predictions = model.predict(test_data)
predicted_labels = np.argmax(predictions, axis=1)
true_labels = np.argmax(test_labels, axis=1)

# Compute Metrics
accuracy = accuracy_score(true_labels, predicted_labels)
precision = precision_score(true_labels, predicted_labels, average='weighted')
recall = recall_score(true_labels, predicted_labels, average='weighted')
f1 = f1_score(true_labels, predicted_labels, average='weighted')

# Compute specificity for each class
conf_matrix = confusion_matrix(true_labels, predicted_labels)
specificity_list = []
for i in range(conf_matrix.shape[0]):  
    tn = conf_matrix.sum() - (conf_matrix[i, :].sum() + conf_matrix[:, i].sum() - conf_matrix[i, i])
    fp = conf_matrix[:, i].sum() - conf_matrix[i, i]
    specificity = tn / (tn + fp) if (tn + fp) > 0 else 0
    specificity_list.append(specificity)

average_specificity = np.mean(specificity_list)


# Confusion Matrix
cm = confusion_matrix(true_labels, predicted_labels)
plt.figure(figsize=(8, 6))
sns.heatmap(cm, annot=True, fmt='d', cmap='Blues',
            xticklabels=trainGenerator.class_indices.keys(),
            yticklabels=trainGenerator.class_indices.keys())
plt.title('Confusion Matrix')
plt.xlabel('Predicted')
plt.ylabel('True')
plt.show()

# Plot Accuracy and Loss Curves
plt.figure(figsize=(12, 4))

# Accuracy
plt.subplot(1, 2, 1)
plt.plot(history.history['accuracy'], label='Train Accuracy')
plt.plot(history.history['val_accuracy'], label='Validation Accuracy')
plt.title('Model Accuracy')
plt.xlabel('Epochs')
plt.ylabel('Accuracy')
plt.legend()

# Loss
plt.subplot(1, 2, 2)
plt.plot(history.history['loss'], label='Train Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.title('Model Loss')
plt.xlabel('Epochs')
plt.ylabel('Loss')
plt.legend()

plt.show()

# ROC-AUC Curve (for each class)
plt.figure(figsize=(8, 6))
for i in range(7):  # 7 classes
    fpr, tpr, _ = roc_curve(test_labels[:, i], predictions[:, i])
    roc_auc = auc(fpr, tpr)
    plt.plot(fpr, tpr, label=f'Class {i} (AUC = {roc_auc:.2f})')

plt.plot([0, 1], [0, 1], 'k--')  # Random classifier line
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('ROC-AUC Curve')
plt.legend()
plt.show()

# Precision-Recall Curve
plt.figure(figsize=(8, 6))
for i in range(7):  # 7 classes
    precision_vals, recall_vals, _ = precision_recall_curve(test_labels[:, i], predictions[:, i])
    plt.plot(recall_vals, precision_vals, label=f'Class {i}')

plt.xlabel('Recall')
plt.ylabel('Precision')
plt.title('Precision-Recall Curve')
plt.legend()
plt.show()

# Print Metrics
print(f"Accuracy(%): {accuracy * 100:.2f}")
print(f"Sensitivity(%): {recall * 100:.2f}")
print(f"Precision(%): {precision * 100:.2f}")
print(f"F1-Score(%): {f1 * 100:.2f}")
print(f"Recall (Sensitivity): {recall * 100:.2f}%")
