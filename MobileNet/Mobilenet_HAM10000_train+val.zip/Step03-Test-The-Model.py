import os
from tensorflow.keras.preprocessing import image
from tensorflow.keras.applications.mobilenet_v2 import MobileNetV2, preprocess_input
from google.colab.patches import cv2_imshow
from PIL import Image
import numpy as np
import tensorflow as tf
import cv2

# Get the list of classes (categories) from the subdirectories
base_directory = "/content/drive/MyDrive/Datasets/MobileNet/Ham10000 Dataset/Classified Images"

# Assume that each subdirectory in the base directory corresponds to a different class
categories = os.listdir(base_directory)
categories.sort()
print("Categories:", categories)

# Load the saved model
path_for_saved_model = "/content/drive/MyDrive/Datasets/MobileNet/Ham10000 Dataset/Classified Images/dataset_for_model/TheHamV2.h5"
model = tf.keras.models.load_model(path_for_saved_model)

# Function to classify the image and display the prediction
def classify_image(imageFile):
    # Prepare the image for prediction
    img = Image.open(imageFile)
    img = img.resize((224, 224), Image.Resampling.LANCZOS)
    x = image.img_to_array(img)
    x = np.expand_dims(x, axis=0)  # Expand dims to match the input shape (batch size, height, width, channels)
    x = preprocess_input(x)
    
    # Make prediction
    pred = model.predict(x)
    categoryValue = np.argmax(pred, axis=1)  # Get the class index
    print("Predicted Category Index:", categoryValue)
    
    categoryValue = categoryValue[0]  # Extract the integer value of the class
    print("Predicted Class:", categories[categoryValue])
    
    # Return the result
    return categories[categoryValue]

# Directory where images are stored (base directory with subdirectories for each class)
output_directory = "/content/drive/MyDrive/Datasets/MobileNet/Ham10000 Dataset/Classified Images/dataset_for_model/predicted_images/"

# Check if output directory exists, if not, create it
if not os.path.exists(output_directory):
    os.makedirs(output_directory)

# Loop through all subdirectories (classes)
for category in categories:
    category_path = os.path.join(base_directory, category)

    # Loop through all images in each category subdirectory
    if os.path.isdir(category_path):  # Check if it's a directory
        for image_name in os.listdir(category_path):
            image_path = os.path.join(category_path, image_name)
            
            # Check if the file is an image (you can add more formats if needed)
            if image_path.endswith('.jpg') or image_path.endswith('.png'):
                resultText = classify_image(image_path)  # Get prediction result
                print(f"Prediction Result for {image_name}: {resultText}")

                # Display the result on the image
                img = cv2.imread(image_path)
                img = cv2.putText(img, resultText, (50, 50), cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 0, 0), 2)

                # Show the image with the prediction text
                cv2_imshow(img)  # Display the image in Google Colab
                
                # Save the image with prediction text
                output_image_path = os.path.join(output_directory, f"predicted_{category}_{image_name}")
                cv2.imwrite(output_image_path, img)

                # Optionally, wait for a keypress before closing (useful outside of Colab)
                cv2.waitKey(0)

# Destroy all OpenCV windows after processing all images
cv2.destroyAllWindows()
